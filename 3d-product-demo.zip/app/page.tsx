import ProductShowcase from "@/components/product-showcase"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import { ThemeProvider } from "@/components/theme-provider"

export default function Home() {
  return (
    <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-1">
          <ProductShowcase />
        </main>
        <Footer />
      </div>
    </ThemeProvider>
  )
}
