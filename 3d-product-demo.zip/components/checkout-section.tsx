"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Smartphone, Truck } from "lucide-react"

export function CheckoutSection({ cart = [] }) {
  const [paymentMethod, setPaymentMethod] = useState("card")

  const totalAmount = cart.reduce((sum, item) => sum + item.price, 0)

  const handleCheckout = (e) => {
    e.preventDefault()
    alert("This is a demo. No actual purchase will be made.")
  }

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold">Checkout</h2>
        <p className="text-muted-foreground">Complete your purchase</p>
      </div>

      <div className="grid md:grid-cols-3 gap-8">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Payment Details</CardTitle>
            <CardDescription>Choose your preferred payment method</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleCheckout}>
              <Tabs defaultValue="card" value={paymentMethod} onValueChange={setPaymentMethod}>
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="card">Card</TabsTrigger>
                  <TabsTrigger value="upi">UPI</TabsTrigger>
                  <TabsTrigger value="cod">COD</TabsTrigger>
                </TabsList>

                <TabsContent value="card" className="space-y-4 pt-4">
                  <div className="space-y-2">
                    <Label htmlFor="card-name">Name on Card</Label>
                    <Input id="card-name" placeholder="John Doe" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="card-number">Card Number</Label>
                    <Input id="card-number" placeholder="1234 5678 9012 3456" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="expiry">Expiry Date</Label>
                      <Input id="expiry" placeholder="MM/YY" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="cvv">CVV</Label>
                      <Input id="cvv" placeholder="123" />
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="upi" className="space-y-4 pt-4">
                  <div className="space-y-2">
                    <Label htmlFor="upi-id">UPI ID</Label>
                    <Input id="upi-id" placeholder="yourname@upi" />
                  </div>
                  <div className="flex items-center justify-center p-4">
                    <Smartphone className="h-16 w-16 text-muted-foreground" />
                  </div>
                  <p className="text-center text-sm text-muted-foreground">
                    You will receive a payment request on your UPI app
                  </p>
                </TabsContent>

                <TabsContent value="cod" className="space-y-4 pt-4">
                  <div className="flex items-center justify-center p-4">
                    <Truck className="h-16 w-16 text-muted-foreground" />
                  </div>
                  <p className="text-center text-sm text-muted-foreground">
                    Pay with cash when your order is delivered
                  </p>
                  <RadioGroup defaultValue="standard" className="pt-2">
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="standard" id="standard" />
                      <Label htmlFor="standard">Standard Delivery (3-5 days)</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="express" id="express" />
                      <Label htmlFor="express">Express Delivery (1-2 days)</Label>
                    </div>
                  </RadioGroup>
                </TabsContent>
              </Tabs>

              <div className="mt-6">
                <Button type="submit" className="w-full">
                  Complete Purchase
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Order Summary</CardTitle>
            <CardDescription>
              {cart.length} item{cart.length !== 1 ? "s" : ""} in cart
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {cart.length > 0 ? (
                cart.map((item, index) => (
                  <div key={index} className="flex justify-between">
                    <span>{item.name}</span>
                    <span>₹{item.price}</span>
                  </div>
                ))
              ) : (
                <p className="text-center text-muted-foreground">Your cart is empty</p>
              )}
            </div>
          </CardContent>
          <CardFooter className="flex flex-col">
            <div className="flex justify-between w-full py-4 border-t">
              <span className="font-bold">Total</span>
              <span className="font-bold">₹{totalAmount}</span>
            </div>
            <div className="w-full pt-2">
              <p className="text-xs text-center text-muted-foreground">
                This is a demo. No actual purchase will be made.
              </p>
            </div>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
