"use client"

import { useState, useRef, Suspense } from "react"
import { Canvas } from "@react-three/fiber"
import { OrbitControls, Environment, ContactShadows, useGLTF, Html } from "@react-three/drei"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { CheckoutSection } from "@/components/checkout-section"
import { ContactSection } from "@/components/contact-section"

const product = {
  id: 2,
  name: "Desk Lamp",
  price: 299,
  description: "Minimalist desk lamp with adjustable brightness. Premium quality with modern design.",
  modelPath: "/assets/3d/duck.glb",
  scale: 2.5,
  position: [0, 0.2, 0],
  rotation: [0, Math.PI / 4, 0],
}

function Model({ modelPath, scale = 1, rotation = [0, 0, 0], position = [0, 0, 0] }) {
  const { scene } = useGLTF(modelPath)

  return <primitive object={scene} scale={scale} rotation={rotation} position={position} />
}

function ProductView({ product, onAddToCart }) {
  return (
    <div className="h-[500px] w-full relative">
      <Badge className="absolute top-4 left-4 z-10">DEMO</Badge>
      <Canvas camera={{ position: [0, 0, 5], fov: 50 }}>
        <ambientLight intensity={0.5} />
        <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} />
        <pointLight position={[-10, -10, -10]} />
        <Suspense fallback={<Html center>Loading 3D model...</Html>}>
          <Model
            modelPath={product.modelPath}
            scale={product.scale}
            rotation={product.rotation}
            position={product.position}
          />
          <Environment preset="city" />
          <ContactShadows position={[0, -1.5, 0]} opacity={0.4} scale={10} blur={1.5} far={1.5} />
          <OrbitControls
            enablePan={false}
            enableZoom={true}
            minPolarAngle={Math.PI / 4}
            maxPolarAngle={Math.PI / 1.5}
            autoRotate
            autoRotateSpeed={1}
          />
        </Suspense>
      </Canvas>

      <div className="absolute bottom-4 left-4 right-4 bg-background/80 backdrop-blur-sm p-4 rounded-lg">
        <h2 className="text-xl font-bold">{product.name}</h2>
        <p className="text-muted-foreground">{product.description}</p>
        <div className="flex justify-between items-center mt-2">
          <span className="text-lg font-semibold">₹{product.price}</span>
          <Button onClick={() => onAddToCart(product)}>Add to Cart</Button>
        </div>
      </div>
    </div>
  )
}

export default function ProductShowcase() {
  const [cart, setCart] = useState([])
  const checkoutRef = useRef(null)
  const contactRef = useRef(null)

  const handleAddToCart = (product) => {
    setCart((prev) => [...prev, product])
    if (checkoutRef.current) {
      checkoutRef.current.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <div className="container py-8 space-y-20">
      <section className="space-y-8">
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold tracking-tight">Interactive 3D Product Demo</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Explore our featured product in 3D. Rotate, zoom, and interact with the item.
          </p>
        </div>

        <div id="products" className="pt-8">
          <div className="max-w-2xl mx-auto">
            <Card>
              <CardContent className="p-0">
                <ProductView product={product} onAddToCart={handleAddToCart} />
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <section id="checkout" ref={checkoutRef} className="pt-8">
        <CheckoutSection cart={cart} />
      </section>

      <section id="contact" ref={contactRef} className="pt-8">
        <ContactSection />
      </section>
    </div>
  )
}
